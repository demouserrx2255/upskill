const config = {
	plugins: {
	  autoprefixer: {},

	},
  };
  export default config;