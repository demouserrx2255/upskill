# Mini E-Commerce API (Node + Express + MongoDB)

Backend for a small e-commerce. Includes auth, products, categories, cart, orders, and local image uploads.

## Quick Start

1. Prereqs: Node 18+, MongoDB running locally
2. Install deps:

```bash
cd ~/ecommerce-mini
npm install
```

3. Configure env in `backend/.env` (already scaffolded):

```ini
PORT=5000
MONGO_URI=mongodb://localhost:27017/ecommerce_mini
JWT_SECRET=changeme_in_prod
JWT_EXPIRES_IN=7d
CORS_ORIGIN=*
```

4. Run:

```bash
npm run dev
```

Healthcheck: `GET http://localhost:5000/health`

Base URL: `http://localhost:5000/api`

## Auth

- POST `/register`
  - Body:
    ```json
    { "name": "Alice", "email": "alice@example.com", "password": "secret123" }
    ```
  - 201:
    ```json
    { "token": "<jwt>", "user": { "id": "...", "name": "Alice", "email": "alice@example.com", "role": "user" } }
    ```

- POST `/login`
  - Body:
    ```json
    { "email": "alice@example.com", "password": "secret123" }
    ```
  - 200: same as register

- GET `/me` (auth)
  - Header: `Authorization: Bearer <jwt>`

## Categories (admin)

- GET `/categories`
- POST `/categories` (admin)
  - Body:
    ```json
    { "name": "Shoes" }
    ```

## Products

- GET `/products`
  - Query: `search`, `category` (slug), `price` (e.g. `0-100`), `sort`, `page`, `limit`
- GET `/products/:id`
- POST `/products` (admin, multipart)
  - Header: `Authorization: Bearer <admin_jwt>`
  - Form-data fields:
    - `name`, `description`, `price`, `category` (slug or id), `stock`
    - `images` (files, multiple)
- PUT `/products/:id` (admin, multipart)
- DELETE `/products/:id` (admin)

## Cart (auth)

- GET `/cart`
- POST `/cart`
  - Body:
    ```json
    { "productId": "<product_id>", "quantity": 2 }
    ```
- DELETE `/cart/:productId`

## Orders

- POST `/orders` (auth)
  - Body (optional to override saved address):
    ```json
    {
      "shippingAddress": {
        "line1": "221B Baker St",
        "city": "London",
        "postalCode": "NW1",
        "country": "UK"
      }
    }
    ```
- GET `/orders` (auth) - my orders
- GET `/orders/admin/all` (admin) - all orders

## Typical Flow

1) Register or login → get JWT
2) (Admin) create category → create product with images
3) (User) list products and add to cart
4) View cart → place order → cart clears
5) View my orders; (Admin) view all orders

## Notes

- Local uploads are under `/uploads`. Use S3 in production.
- Set `role` manually in DB to promote an admin:

```js
// in Mongo shell or script
use ecommerce_mini
db.users.updateOne({ email: 'admin@example.com' }, { $set: { role: 'admin' } })
``` 