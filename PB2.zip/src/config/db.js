import mongoose from 'mongoose';

export async function connectToDatabase() {
	const mongoUri =  `mongodb://vraj_marvania:deep70@radixusers2.com:27017/vraj_marvania?authSource=vraj_marvania`
	// const mongoUri = process.env.PORT
	console.log("mongoUri: ", mongoUri);
	if (!mongoUri) {
		throw new Error('MONGO_URI is not defined in environment');
	}
	mongoose.set('strictQuery', true);
	await mongoose.connect(mongoUri, {
		serverSelectionTimeoutMS: 10000,
	});
	console.log('MongoDB connected');
} 