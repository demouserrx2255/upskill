export function notFoundHandler(req, res, _next) {
	res.status(404).json({ message: 'Not Found' });
}

export function globalErrorHandler(err, _req, res, _next) {
	const statusCode = err.statusCode || 500;
	const message = err.message || 'Internal Server Error';
	res.status(statusCode).json({ message });
} 