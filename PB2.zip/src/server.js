import dotenv from 'dotenv';
import { connectToDatabase } from './config/db.js';
import app from './app.js';

// Load env from project root
dotenv.config();

const PORT = process.env.PORT;
console.log(PORT);
connectToDatabase()
	.then(() => {
		app.listen(PORT, () => {
			console.log(`Server running on port ${PORT}`);
		});
	})
	.catch((error) => {
		console.error('Failed to start server due to DB error:', error);
		process.exit(1);
	}); 