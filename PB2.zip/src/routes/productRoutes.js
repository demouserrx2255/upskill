import { Router } from 'express';
import multer from 'multer';
import { listProducts, getProduct, createProduct, updateProduct, deleteProduct } from '../controllers/productController.js';
import { protect, authorizeRoles } from '../middlewares/auth.js';
import path from 'path';
import { fileURLToPath } from 'url';

const router = Router();

// Get the directory name for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const storage = multer.diskStorage({
	destination: function (_req, _file, cb) {
		// Use path.join for cross-platform compatibility
		cb(null, path.join(__dirname, '../uploads'));
	},
	filename: function (_req, file, cb) {
		const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
		cb(null, `${unique}-${file.originalname}`);
	},
});  
const upload = multer({ storage });

router.get('/', listProducts);
router.get('/:id', getProduct);

router.post('/', protect, authorizeRoles('admin'), upload.array('images', 5), createProduct);
router.put('/:id', protect, authorizeRoles('admin'), upload.array('images', 5), updateProduct);
router.delete('/:id', protect, authorizeRoles('admin'), deleteProduct);

export default router; 