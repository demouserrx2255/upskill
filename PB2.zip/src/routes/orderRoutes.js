import { Router } from 'express';
import { protect, authorizeRoles } from '../middlewares/auth.js';
import { placeOrder, getMyOrders, getAllOrders, getAnalytics, updateOrderStatus } from '../controllers/orderController.js';

const router = Router();

router.post('/', protect, placeOrder);
router.put('/:orderId', protect, updateOrderStatus);
router.get('/', protect, getMyOrders);
router.get('/analytics', protect, getAnalytics);
router.get('/admin/all', protect, authorizeRoles('admin'), getAllOrders);

export default router; 