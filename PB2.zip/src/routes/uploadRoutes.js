import { Router } from 'express';
import multer from 'multer';
import { uploadImage } from '../controllers/uploadController.js';
import { protect, authorizeRoles } from '../middlewares/auth.js';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const router = Router();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const storage = multer.diskStorage({
	destination: function (_req, _file, cb) {
		cb(null, join(__dirname, '..', 'uploads'));
	},
	filename: function (_req, file, cb) {
		const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
		cb(null, `${unique}-${file.originalname}`);
	},
});

const upload = multer({ storage });

router.post('/', protect, authorizeRoles('admin'), upload.array('images', 5), uploadImage);

export default router; 