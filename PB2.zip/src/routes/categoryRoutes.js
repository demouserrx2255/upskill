import { Router } from 'express';
import { listCategories, createCategory, deleteCategory, updateCategory } from '../controllers/categoryController.js';
import { protect, authorizeRoles } from '../middlewares/auth.js';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
// Get the directory name for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const storage = multer.diskStorage({
    destination: function (_req, _file, cb) {
        // Use path.join for cross-platform compatibility
        cb(null, path.join(__dirname, '../uploads'));
    },
    filename: function (_req, file, cb) {
        const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
        cb(null, `${unique}-${file.originalname}`);
    },
});  
const router = Router();
const upload = multer({ storage });

router.get('/', listCategories);
router.post('/', protect, authorizeRoles('admin'),upload.array('images', 5), createCategory);
router.delete('/:id', protect, authorizeRoles('admin'), deleteCategory);
router.put('/:id', protect, authorizeRoles('admin'), upload.array('images', 5), updateCategory);

export default router;