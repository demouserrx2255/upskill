import mongoose from 'mongoose';

const orderItemSchema = new mongoose.Schema(
	{
		product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
		name: String,
		price: Number,
		quantity: { type: Number, default: 1 },
	},
	{ _id: false }
);

const orderSchema = new mongoose.Schema(
	{
		user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
		items: [orderItemSchema],
		totalAmount: { type: Number, required: true },
		shippingAddress: {
			line1: String,
			line2: String,
			city: String,
			state: String,
			postalCode: String,
			country: String,
		},
		status: { type: String, enum: ['pending', 'paid', 'shipped', 'delivered', 'cancelled'], default: 'pending' },
	},
	{ timestamps: true }
);

export default mongoose.model('Order', orderSchema); 