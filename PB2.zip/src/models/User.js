import mongoose from 'mongoose';

const cartItemSchema = new mongoose.Schema(
	{
		product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
		quantity: { type: Number, default: 1, min: 1 },
	},
	{ _id: false }
);

const userSchema = new mongoose.Schema(
	{
		name: { type: String, required: true },
		email: { type: String, required: true, unique: true, index: true },
		password: { type: String, required: true, select: false },
		role: { type: String, enum: ['user', 'admin'], default: 'user' },
		cart: [cartItemSchema],
		address: {
			line1: String,
			line2: String,
			city: String,
			state: String,
			postalCode: String,
			country: String,
		},
	},
	{ timestamps: true }
);

export default mongoose.model('User', userSchema); 