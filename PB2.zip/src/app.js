import express from "express";
import morgan from "morgan";
import cors from "cors";
import cookieParser from "cookie-parser";

import authRoutes from "./routes/authRoutes.js";
import productRoutes from "./routes/productRoutes.js";
import categoryRoutes from "./routes/categoryRoutes.js";
import cartRoutes from "./routes/cartRoutes.js";
import orderRoutes from "./routes/orderRoutes.js";
import uploadRoutes from "./routes/uploadRoutes.js";
import {
  notFoundHandler,
  globalErrorHandler,
} from "./middlewares/errorHandler.js";

const app = express();

// Core middleware
app.use(
  cors({
    origin: process.env.CORS_ORIGIN
      ? process.env.CORS_ORIGIN
      : "http://localhost:3000",
    credentials: true,
  })
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
if (process.env.NODE_ENV !== "test") {
  app.use(morgan("dev"));
}

// Static for local uploads
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Debug: Log the uploads directory path
console.log("Uploads directory path:", join(__dirname, "uploads"));

app.use("/uploads", express.static(join(__dirname, "uploads")));

// Test route to verify uploads are accessible
app.get("/test-uploads", (req, res) => {
  res.json({
    uploadsDir: join(__dirname, "uploads"),
    message: "Uploads directory configured",
  });
});

// Healthcheck
app.get("/health", (_req, res) => {
  res.json({ ok: true });
});

// API routes
app.use("/api", authRoutes);
app.use("/api/products", productRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/cart", cartRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/upload", uploadRoutes);
app.use(express.json());

// 404 and error handlers
app.use(notFoundHandler);
app.use(globalErrorHandler);

export default app;
