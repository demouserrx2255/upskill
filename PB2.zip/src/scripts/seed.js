import dotenv from 'dotenv';
import mongoose from 'mongoose';
import { connectToDatabase } from '../config/db.js';
import Category from '../models/Category.js';
import Product from '../models/Product.js';

async function seed() {
	dotenv.config();
	await connectToDatabase();

	const existingProducts = await Product.countDocuments();
	if (existingProducts > 0) {
		console.log(`Products already exist: ${existingProducts}. Skipping seeding.`);
		await mongoose.connection.close();
		return;
	}

	const categoriesData = [
		{ name: 'Electronics', slug: 'electronics' },
		{ name: 'Books', slug: 'books' },
		{ name: 'Clothing', slug: 'clothing' },
	];
	const categories = await Category.insertMany(categoriesData);
	const catBySlug = Object.fromEntries(categories.map((c) => [c.slug, c]));

	const productsData = [
		{ name: 'Wireless Headphones', description: 'Noise-cancelling over-ear headphones', price: 99.99, category: catBySlug['electronics']._id, stock: 100, images: [] },
		{ name: 'Smartphone', description: 'Latest gen smartphone', price: 699.0, category: catBySlug['electronics']._id, stock: 50, images: [] },
		{ name: 'Novel: The Great Tale', description: 'Bestselling fiction novel', price: 14.99, category: catBySlug['books']._id, stock: 200, images: [] },
		{ name: 'T-Shirt', description: '100% cotton tee', price: 19.99, category: catBySlug['clothing']._id, stock: 150, images: [] },
	];

	await Product.insertMany(productsData);
	console.log('Seeded categories and products.');
	await mongoose.connection.close();
}

seed().catch(async (err) => {
	console.error(err);
	try { await mongoose.connection.close(); } catch {}
	process.exit(1);
}); 