import Product from '../models/Product.js';
import Category from '../models/Category.js';

export async function listProducts(req, res) {
	const { search, category, price, sort = '-createdAt', page = 1, limit = 10 } = req.query;
	console.log("category: ", category);
	const query = {};
	if (search) {
		query.$text = { $search: search };
	}
	if (category) {
		const cat = await Category.findOne({ slug: category });
		if (cat) query.category = cat._id;
		query.category = category;
	}
	if (price) {
		const [min, max] = String(price).split('-').map(Number);
		query.price = {};
		if (!isNaN(min)) query.price.$gte = min;
		if (!isNaN(max)) query.price.$lte = max;
	}
	const skip = (Number(page) - 1) * Number(limit);
	const [items, total] = await Promise.all([
		Product.find(query).populate('category').sort(sort).skip(skip).limit(Number(limit)),
		Product.countDocuments(query),
	]);
	res.json({ items, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
}

export async function getProduct(req, res) {
	const product = await Product.findById(req.params.id).populate('category');
	if (!product) return res.status(404).json({ message: 'Product not found' });
	res.json(product);
}

export async function createProduct(req, res) {
	const { name, description, price, category, stock } = req.body;
	
	// Validate that category is provided and not empty
	if (!category || category.trim() === '') {
		return res.status(400).json({ message: 'Category is required' });
	}
	
	const categoryDoc = await Category.findOne({ slug: category }) || await Category.findById(category);
	if (!categoryDoc) return res.status(400).json({ message: 'Invalid category' });
	const images = (req.files || []).map((f) => `/uploads/${f.filename}`);
	const product = await Product.create({ name, description, price, category: categoryDoc._id, stock, images });
	res.status(201).json(product);
}

export async function updateProduct(req, res) {
	const updates = { ...req.body };
	if (updates.category) {
		const categoryDoc = await Category.findOne({ slug: updates.category }) || await Category.findById(updates.category);
		if (!categoryDoc) return res.status(400).json({ message: 'Invalid category' });
		updates.category = categoryDoc._id;
	}
	if (req.files && req.files.length) {
		updates.$push = { images: { $each: req.files.map((f) => `/uploads/${f.filename}`) } };
	}
	const product = await Product.findByIdAndUpdate(req.params.id, updates, { new: true });
	if (!product) return res.status(404).json({ message: 'Product not found' });
	res.json(product);
}

export async function deleteProduct(req, res) {
	const product = await Product.findByIdAndDelete(req.params.id);
	if (!product) return res.status(404).json({ message: 'Product not found' });
	res.json({ message: 'Product deleted' });
} 