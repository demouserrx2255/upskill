import slugify from 'slugify';
import Category from '../models/Category.js';

export async function listCategories(_req, res) {
	const items = await Category.find().sort('name');
	res.json(items);
}

export async function createCategory(req, res) {
	console.log(req,req.body, req.files, '--------------------------------------');
	const { name } = req.body;
	if (!name) return res.status(400).json({ message: 'Name is required' });

	const slug = slugify(name, { lower: true });
	const exists = await Category.findOne({ slug });
	if (exists) return res.status(400).json({ message: 'Category exists' });

	// Extract file paths from req.files
	// const images = req.files ? req.files.map((file) => file.path) : [];
	const images = (req.files || []).map((f) => `/uploads/${f.filename}`);
	console.log("images: ", images);

	const category = await Category.create({ name, slug, images });
	res.status(201).json(category);
}

export const deleteCategory = async (req, res) => {
    try {
        const { id } = req.params;
		console.log("id: ", id);
        const category = await Category.findByIdAndDelete(id);
		console.log("category: ", category);
        if (!category) {
            return res.status(404).json({ message: 'Category not found' });
        }
        res.status(200).json({ message: 'Category deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

export const updateCategory = async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;
        if (req.files) {
            updates.images = req.files.map(file => file.path);
        }
        const category = await Category.findByIdAndUpdate(id, updates, { new: true });
        if (!category) {
            return res.status(404).json({ message: 'Category not found' });
        }
        res.status(200).json(category);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};