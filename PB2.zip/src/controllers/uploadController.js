export function uploadImage(req, res) {
	const files = (req.files || []).map((f) => ({ filename: f.filename, url: `/uploads/${f.filename}` }));
	res.status(201).json({ files });
} 