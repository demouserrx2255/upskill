import User from '../models/User.js';
import Order from '../models/Order.js';
import Product from '../models/Product.js';

import { console } from 'inspector';

export async function placeOrder(req, res) {
	const user = await User.findById(req.user._id).populate('cart.product');
	if (!user.cart.length) return res.status(400).json({ message: 'Cart is empty' });
	const items = user.cart.map((item) => ({
		product: item.product._id,
		name: item.product.name,
		price: item.product.price,
		quantity: item.quantity,
	}));
	const totalAmount = items.reduce((sum, it) => sum + it.price * it.quantity, 0);
	const shippingAddress = req.body.shippingAddress || user.address || {};
	const order = await Order.create({ user: user._id, items, totalAmount, shippingAddress, status: 'paid' });
	user.cart = [];
	await user.save();
	res.status(201).json(order);
}


export async function updateOrderStatus(req, res) {
    const orderId = req.params.orderId;

  console.log("orderId: ", orderId);
  const { status } = req.body;
  console.log("status: ", status);

  // Optional: Validate status input
  const validStatuses = ['pending', 'paid', 'shipped', 'delivered', 'cancelled'];
  if (!validStatuses.includes(status)) {
    return res.status(400).json({ message: 'Invalid status value' });
  }
  console.log(orderId);
  try {
    const updatedOrder = await Order.findByIdAndUpdate(
      orderId,
      { status },
      { new: true }
    ).populate('items.product');  // Optionally populate product if you want to return full details
	console.log("updatedOrder: ", updatedOrder);
    if (!updatedOrder) {
      return res.status(404).json({ message: 'Order not found' });
    }

    res.json(updatedOrder);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update order status', error: error.message });
  }
}

export async function getMyOrders(req, res) {
	const orders = await Order.find({ user: req.user._id }).sort('-createdAt').populate('items.product');;
	res.json(orders);
}

export async function getAllOrders(_req, res) {
	const orders = await Order.find().populate('user', 'name email').sort('-createdAt');
	res.json(orders);
} 

export async function getAnalytics(_req, res) {
	const orders = await Order.find().populate('user', 'name email').sort('-createdAt');
	const user = await User.find();
    const product = await Product.find();
	console.log(orders)
	res.json({
        totalOrders: orders.length,
        totalRevenue: orders.some(()=>true) ? orders.reduce((sum, o) => sum + (o.totalAmount || 0), 0) : 0,
        totalProducts: product.length,
        totalUsers: user.length,
        recentOrders: orders,
      });
}   