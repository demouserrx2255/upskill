import User from '../models/User.js';
import Product from '../models/Product.js';

export async function getCart(req, res) {
	const user = await User.findById(req.user._id).populate('cart.product');
	res.json({ cart: user.cart });
}

export async function addToCart(req, res) {
	const { productId, quantity = 1 } = req.body;
	const product = await Product.findById(productId);
	if (!product) return res.status(404).json({ message: 'Product not found' });
	const user = await User.findById(req.user._id);
	const existing = user.cart.find((item) => item.product.toString() === productId);
	if (existing) {
		existing.quantity = Number(quantity);
	} else {
		user.cart.push({ product: productId, quantity: Number(quantity) });
	}
	console.log(user.cart,"user.cart")
	await user.save();
	await user.populate('cart.product');
	res.status(201).json({ cart: user.cart });
}

export async function removeFromCart(req, res) {
	const { productId } = req.params;
	const user = await User.findById(req.user._id);
	user.cart = user.cart.filter((item) => item.product.toString() !== productId);
	await user.save();
	res.json({ cart: user.cart });
} 