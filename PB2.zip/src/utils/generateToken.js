import jwt from 'jsonwebtoken';

export function generateJwtToken(userId) {
	return jwt.sign({ id: userId }, process.env.JWT_SECRET || 'f045432d09c2ad29c918ad600b6be1394ab26c08', {
		expiresIn: process.env.JWT_EXPIRES_IN || '7d',
	});
} 